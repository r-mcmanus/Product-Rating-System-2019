﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Rating_System.Entity;
using Product_Rating_System.Boundary;
using System.IO;
using System.Drawing;

namespace Product_Rating_System.Control
{
    class UploaderControl:Controller
    {
        private string username;
        private ProductList productList;
        private UserHomePage homePage;
        public void AddProduct()
        {
            AddProductForm addProductForm = new AddProductForm(username, this);
            addProductForm.ShowDialog();         
        }
        public bool Upload(string name, string price, string imagePath)
        {
            bool isError = false;
            decimal d;
            if (!(decimal.TryParse(price, out d))
               && d >= 0
               && d * 100 == Math.Floor(d * 100) || 
               string.IsNullOrWhiteSpace(name) ||
               string.IsNullOrEmpty(imagePath)){
                    System.Windows.Forms.MessageBox.Show("Product upload was unsuccessful. Please make sure to fill out all criteria and try again.",
                        "Upload Failed", System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Error);
                isError = true;
            }
            else
            {
                Product product = new Product(name, d, username);
                product.FileName = Path.GetFileName(imagePath);
                File.Copy(imagePath, Path.GetFullPath("Images\\" + product.FileName));
                product.ProductImage = Image.FromFile(Path.GetFullPath("Images\\" + product.FileName));
                DBConnector connector = new DBConnector();
                connector.AddProduct(product);
                System.Windows.Forms.MessageBox.Show("Your product has been uploaded!");
                productList = connector.GetProductList(username);
                homePage.AddToList(product);               
            }
            return isError;
        }
        public UploaderControl(string aUsername, UserHomePage theHomePage)
        {
            username = aUsername;
            homePage = theHomePage;
        }
    }
}
