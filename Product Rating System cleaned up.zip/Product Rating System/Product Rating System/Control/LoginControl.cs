﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Rating_System.Entity;
using Product_Rating_System.Boundary;

namespace Product_Rating_System.Control
{
    class LoginControl : Controller
    {
        public User User { get; set; }
        public ProductList ProductList {get;set;}
        public void Login(string username, string password)
        {
            byte[] data = Encoding.ASCII.GetBytes(password);
            data = new System.Security.Cryptography.SHA256Managed().ComputeHash(data);            
            string binaryString = "";
            for (int i = 0; i < data.Length; i++)
            {
                binaryString += Convert.ToString(data[i], 2);          
            }
            DBConnector connector = new DBConnector();
            User = connector.GetUser(username, binaryString);
            if (User == null)
            {               
                System.Windows.Forms.MessageBox.Show("The username or password you entered is incorrect.",
                    "Unable to sign in", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);
            }        
            else
            {
                ProductList = connector.GetProductList(User.Username);
                UserHomePage homepage = new UserHomePage(User, ProductList);
                homepage.Show();               
                UserLoginRecord loginRecord = new UserLoginRecord(User.Username);
                connector.SaveUser(loginRecord);                        
            }
        }     
    }
}
