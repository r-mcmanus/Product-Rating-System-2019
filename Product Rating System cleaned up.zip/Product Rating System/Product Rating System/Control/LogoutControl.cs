﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Rating_System.Entity;
using Product_Rating_System.Boundary;

namespace Product_Rating_System.Control
{
    class LogoutControl : Controller
    {       
        private string username;       
        public LogoutControl(string aUsername)
        {
            username = aUsername;        
        }
        public void Logout(string username)
        {
            DBConnector connector = new DBConnector();           
            UserLogoutRecord logoutRecord = new UserLogoutRecord(username);
            connector.SaveUser(logoutRecord);
            LoginForm loginform = new LoginForm();
            loginform.ShowDialog();
        }
    } 
} 