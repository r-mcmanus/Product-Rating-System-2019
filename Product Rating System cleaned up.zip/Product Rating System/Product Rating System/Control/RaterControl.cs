﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Rating_System.Entity;
using Product_Rating_System.Boundary;

namespace Product_Rating_System.Control
{
    class RaterControl: Controller
    {
        private string productName;
        private User user;
        private ProductList ProductList;
        private UserHomePage homePage;
        public RaterControl(User aUser, string aProductName, UserHomePage theHomePage)
        {
            user = aUser;
            productName = aProductName;
            homePage = theHomePage;
        }
        public void RateProduct()
        {
            RateProductForm rateProductForm = new RateProductForm(user.Username, this);
            rateProductForm.ShowDialog(homePage);
        }
        public bool updateRating(int rating)
        {
            bool isError = false;
            if (rating == 0)
            {
                System.Windows.Forms.MessageBox.Show("Rating was unsuccessful. Please make sure to click on a star from 1-5.",
                        "Rating Failed", System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Error);
                isError = true;
            }
            else
            {
                DBConnector connector = new DBConnector();
                connector.Update(user.Username, productName, rating);
                System.Windows.Forms.MessageBox.Show("Your rating has been received!");
                ProductList = connector.GetProductList(user.Username);
                UserHomePage homePage = new UserHomePage(user, ProductList);
                homePage.Show();
            }
            return isError;
        }
    }
}
