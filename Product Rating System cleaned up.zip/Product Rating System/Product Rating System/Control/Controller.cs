﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Rating_System.Entity;
using Product_Rating_System.Boundary;

namespace Product_Rating_System.Control
{
    class Controller
    {
    }
}
