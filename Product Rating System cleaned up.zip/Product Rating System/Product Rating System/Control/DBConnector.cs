﻿using Product_Rating_System.Entity;
using System.Data.SqlClient;

namespace Product_Rating_System.Control
{
    class DBConnector
    {
        string connectionString, commandString;
        SqlConnection connection; 
        public User GetUser(string username, string password)
        {           
            User user = new User();
            connection = new SqlConnection(connectionString);
            connection.Open();
            commandString = "execute validateUser N'" + username 
                + "', N'" + password + "'";
            SqlCommand command = new SqlCommand(commandString, connection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();

            if (reader.HasRows)
            {
                user.Username = reader.GetString(0);
                user.Password = reader.GetString(1);
                user.Type = reader.GetString(2)[0];
            }
            else
                user = null;
            
            connection.Close();
            return user;        
        }
        public void AddProduct(Product product)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            commandString = "execute addProduct N'" +
                product.ProductName + "', " + product.ProductPrice
                + ", N'" + product.FileName + "', N'" + 
                product.UploaderUsername + "'";
            SqlCommand command = new SqlCommand(commandString,
                connection);
            command.ExecuteReader();
            connection.Close();
        }
        public ProductList GetProductList(string username)
        {
            int count, i = 0;
            connection = new SqlConnection(connectionString);
            connection.Open();
            commandString = "select count(*) from products";
            SqlCommand command = new SqlCommand(commandString, connection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();
            count = reader.GetInt32(0);
            if (count == 0)
                return null;
            Product[] products = new Product[count];
            connection.Close();
            connection.Open();
            commandString = "execute getProducts N'" + username 
                + "'";
            command = new SqlCommand(commandString, connection);
            reader = command.ExecuteReader();
            
            while (reader.Read())
            {
                products[i] = new Product(reader.GetString(0),
                    reader.GetDecimal(1), reader.GetString(2),
                    reader.GetString(4));

                if (reader.IsDBNull(3))
                    products[i].ProductRating = 0;
                else
                    products[i].ProductRating = reader.GetDecimal(3);

                if (reader.IsDBNull(5))
                    products[i].IsAlreadyRated = false;
                else
                    products[i].IsAlreadyRated = true;
                i++;
            }
            connection.Close();
            ProductList list = new ProductList(products);
            return list;
        }
        public void SaveUser(UserLoginRecord record)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            commandString = "execute insertRecord 0, N'" +
                record.LoggedInUser + "'";
            SqlCommand command = new SqlCommand(commandString, 
                connection);
            command.ExecuteReader();
            connection.Close();
        }
        public void SaveUser(UserLogoutRecord record)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            commandString = "execute insertRecord 1, N'" +
                record.LoggedOutUser + "'";
            SqlCommand command = new SqlCommand(commandString, 
                connection);
            command.ExecuteReader();
            connection.Close();
        }
        public void Update(string userName, string productName, int rating)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            commandString = "execute updateRating N'" +
                productName.Replace("'", "''") + "', " + rating + ", N'" + userName + "'";
            SqlCommand command = new SqlCommand(commandString,
                connection);
            command.ExecuteReader();
            connection.Close();
        }
        public DBConnector()
        {
            connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\mcman\\source\\repos\\Product Rating System\\Product Rating System\\PRSDatabase.mdf\";Integrated Security=True;Connect Timeout=30";
        }
    }
}
