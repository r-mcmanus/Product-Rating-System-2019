﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Product_Rating_System.Control;
using Product_Rating_System.Entity;

namespace Product_Rating_System.Boundary
{
    public partial class AddProductForm : Product_Rating_System.Boundary.Form1
    {
        private string username;
        private UploaderControl controller;
        public AddProductForm()
        {
            InitializeComponent();
        }

        public AddProductForm(string aUsername,
            object theController)
        {
            InitializeComponent();
            username = aUsername;
            controller = (UploaderControl)theController;
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "C:\\";
            openFileDialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.PNG)|*.BMP;*.JPG;*.GIF;*PNG";
            openFileDialog.ShowDialog();
            txtImage.Text = openFileDialog.FileName;
        }
        private void btnUpload_Click(object sender, EventArgs e)
        {
            bool isError = controller.Upload(txtProductname.Text.Replace("'","''"),
                txtPrice.Text, txtImage.Text);
            if (!isError)
                Close();
        }
    }
}
