﻿namespace Product_Rating_System.Boundary
{
    partial class RateProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblRateThisProduct = new System.Windows.Forms.Label();
            this.labelClickarating = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnStar5 = new System.Windows.Forms.Label();
            this.btnStar3 = new System.Windows.Forms.Label();
            this.btnStar4 = new System.Windows.Forms.Label();
            this.btnStar2 = new System.Windows.Forms.Label();
            this.btnStar1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRateThisProduct
            // 
            this.lblRateThisProduct.AutoSize = true;
            this.lblRateThisProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRateThisProduct.Location = new System.Drawing.Point(457, 62);
            this.lblRateThisProduct.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblRateThisProduct.Name = "lblRateThisProduct";
            this.lblRateThisProduct.Size = new System.Drawing.Size(508, 69);
            this.lblRateThisProduct.TabIndex = 1;
            this.lblRateThisProduct.Text = "Rate This Product";
            // 
            // labelClickarating
            // 
            this.labelClickarating.AutoSize = true;
            this.labelClickarating.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClickarating.Location = new System.Drawing.Point(481, 156);
            this.labelClickarating.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelClickarating.Name = "labelClickarating";
            this.labelClickarating.Size = new System.Drawing.Size(443, 40);
            this.labelClickarating.TabIndex = 2;
            this.labelClickarating.Text = "Click a rating between 1-5.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 434);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 40);
            this.label1.TabIndex = 3;
            this.label1.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1279, 451);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 40);
            this.label5.TabIndex = 4;
            this.label5.Text = "5";
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(611, 664);
            this.btnOK.Margin = new System.Windows.Forms.Padding(5);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(177, 71);
            this.btnOK.TabIndex = 9;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnStar5
            // 
            this.btnStar5.AutoSize = true;
            this.btnStar5.Font = new System.Drawing.Font("Microsoft Sans Serif", 66F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStar5.Location = new System.Drawing.Point(1048, 318);
            this.btnStar5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnStar5.Name = "btnStar5";
            this.btnStar5.Size = new System.Drawing.Size(232, 224);
            this.btnStar5.TabIndex = 20;
            this.btnStar5.Text = "☆";
            this.btnStar5.Click += new System.EventHandler(this.btnStar5_Click);
            // 
            // btnStar3
            // 
            this.btnStar3.AutoSize = true;
            this.btnStar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 66F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStar3.Location = new System.Drawing.Point(614, 318);
            this.btnStar3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnStar3.Name = "btnStar3";
            this.btnStar3.Size = new System.Drawing.Size(232, 224);
            this.btnStar3.TabIndex = 22;
            this.btnStar3.Text = "☆";
            this.btnStar3.Click += new System.EventHandler(this.btnStar3_Click);
            // 
            // btnStar4
            // 
            this.btnStar4.AutoSize = true;
            this.btnStar4.Font = new System.Drawing.Font("Microsoft Sans Serif", 66F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStar4.Location = new System.Drawing.Point(826, 318);
            this.btnStar4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnStar4.Name = "btnStar4";
            this.btnStar4.Size = new System.Drawing.Size(232, 224);
            this.btnStar4.TabIndex = 23;
            this.btnStar4.Text = "☆";
            this.btnStar4.Click += new System.EventHandler(this.btnStar4_Click);
            // 
            // btnStar2
            // 
            this.btnStar2.AutoSize = true;
            this.btnStar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 66F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStar2.Location = new System.Drawing.Point(372, 318);
            this.btnStar2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnStar2.Name = "btnStar2";
            this.btnStar2.Size = new System.Drawing.Size(232, 224);
            this.btnStar2.TabIndex = 24;
            this.btnStar2.Text = "☆";
            this.btnStar2.Click += new System.EventHandler(this.btnStar2_Click);
            // 
            // btnStar1
            // 
            this.btnStar1.AutoSize = true;
            this.btnStar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 66F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStar1.Location = new System.Drawing.Point(115, 318);
            this.btnStar1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnStar1.Name = "btnStar1";
            this.btnStar1.Size = new System.Drawing.Size(232, 224);
            this.btnStar1.TabIndex = 25;
            this.btnStar1.Text = "☆";
            this.btnStar1.Click += new System.EventHandler(this.btnStar1_Click);
            // 
            // RateProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.ClientSize = new System.Drawing.Size(1400, 787);
            this.Controls.Add(this.btnStar1);
            this.Controls.Add(this.btnStar2);
            this.Controls.Add(this.btnStar4);
            this.Controls.Add(this.btnStar3);
            this.Controls.Add(this.btnStar5);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelClickarating);
            this.Controls.Add(this.lblRateThisProduct);
            this.Name = "RateProductForm";
            this.Text = "Rate Product";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblRateThisProduct;
        private System.Windows.Forms.Label labelClickarating;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label btnStar5;
        private System.Windows.Forms.Label btnStar3;
        private System.Windows.Forms.Label btnStar4;
        private System.Windows.Forms.Label btnStar2;
        private System.Windows.Forms.Label btnStar1;
    }
}
