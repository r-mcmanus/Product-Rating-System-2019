﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Product_Rating_System.Control;
using Product_Rating_System.Entity;

namespace Product_Rating_System.Boundary
{
    public partial class RateProductForm : Product_Rating_System.Boundary.Form1
    {
        private string username;
        private int rating = 0;
        private RaterControl controller;
        public RateProductForm()
        {
            InitializeComponent();
        }
        public RateProductForm(string aUserName, object theController)
        {
            InitializeComponent();
            username = aUserName;
            controller = (RaterControl)theController;
        }
        private void btnStar1_Click(object sender, EventArgs e) //this is btnStar1
        {
            btnStar1.Text = "★";
            btnStar1.ForeColor = Color.Gold;
            btnStar2.Text = "☆";
            btnStar2.ForeColor = Color.Black;
            btnStar3.Text = "☆";
            btnStar3.ForeColor = Color.Black;
            btnStar4.Text = "☆";
            btnStar4.ForeColor = Color.Black;
            btnStar5.Text = "☆";
            btnStar5.ForeColor = Color.Black;
            rating = 1;
        }
        private void btnStar2_Click(object sender, EventArgs e)
        {
            btnStar2.Text = "★";
            btnStar2.ForeColor = Color.Gold;

            btnStar1.Text = "☆";
            btnStar1.ForeColor = Color.Black;
            btnStar3.Text = "☆";
            btnStar3.ForeColor = Color.Black;
            btnStar4.Text = "☆";
            btnStar4.ForeColor = Color.Black;
            btnStar5.Text = "☆";
            btnStar5.ForeColor = Color.Black;
            rating = 2;
        }
        private void btnStar3_Click(object sender, EventArgs e)
        {
            btnStar3.Text = "★";
            btnStar3.ForeColor = Color.Gold;
            btnStar1.Text = "☆";
            btnStar1.ForeColor = Color.Black;
            btnStar2.Text = "☆";
            btnStar2.ForeColor = Color.Black;
            btnStar4.Text = "☆";
            btnStar4.ForeColor = Color.Black;
            btnStar5.Text = "☆";
            btnStar5.ForeColor = Color.Black;
            rating = 3;
        }
        private void btnStar4_Click(object sender, EventArgs e)
        {
            btnStar4.Text = "★";
            btnStar4.ForeColor = Color.Gold;
            btnStar1.Text = "☆";
            btnStar1.ForeColor = Color.Black;
            btnStar2.Text = "☆";
            btnStar2.ForeColor = Color.Black;
            btnStar3.Text = "☆";
            btnStar3.ForeColor = Color.Black;
            btnStar5.Text = "☆";
            btnStar5.ForeColor = Color.Black;
            rating = 4;
        }
        private void btnStar5_Click(object sender, EventArgs e)
        {
            btnStar5.Text = "★";
            btnStar5.ForeColor = Color.Gold;
            btnStar1.Text = "☆";
            btnStar1.ForeColor = Color.Black;
            btnStar2.Text = "☆";
            btnStar2.ForeColor = Color.Black;
            btnStar3.Text = "☆";
            btnStar3.ForeColor = Color.Black;
            btnStar4.Text = "☆";
            btnStar4.ForeColor = Color.Black;
            rating = 5;
        }       
        private void btnOK_Click(object sender, EventArgs e)
        {
            bool isError = controller.updateRating(rating);
            if (!isError)
            {
                Owner.Close();
                Close();               
            }
        }       
    } 
} 
