﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Product_Rating_System.Control;
using Product_Rating_System.Entity;

namespace Product_Rating_System.Boundary
{
    public partial class UserHomePage : Product_Rating_System.Boundary.Form1
    {
        private User user;
        private ProductList productList;
        private int x = 15, y = 110;       
        public UserHomePage()
        {
            InitializeComponent();
            Text = "Home Page";
        }

        public UserHomePage(User user, ProductList productList)
        {
            InitializeComponent();
            this.user = user;
            this.productList = productList;
            Text = "Home Page";          
        }
        private void UserHomePage_Load(object sender, EventArgs e)
        {
            if (user.Type == 'r')
                btnAdd.Visible = false;
            lblUsername.Text += " " + user.Username;
            if (productList != null)
            {
                for (int i = 0; i < productList.Products.Length; i++)
                {                  
                    PictureBox picture = new PictureBox();
                    picture.Location = new Point(x, y);
                    picture.Size = new Size(125, 110);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Image = productList.Products[i].ProductImage;
                    Controls.Add(picture);

                    Label lblProductName = new Label();
                    lblProductName.Location = new Point(x + 130, y);
                    lblProductName.Text = productList.Products[i].ProductName;
                    lblProductName.Size = new Size(200, 20);
                    lblProductName.Font = new Font("Microsoft Sans Serif", 10);
                    Controls.Add(lblProductName);

                    Label lblUploader = new Label();
                    lblUploader.Location = new Point(x + 130, y + 20);
                    lblUploader.Text = "Uploaded by " +
                        productList.Products[i].UploaderUsername;
                    lblUploader.Size = new Size(200, 20);
                    Controls.Add(lblUploader);

                    Label lblPrice = new Label();
                    lblPrice.Location = new Point(x + 130, y + 40);
                    lblPrice.Text = productList.Products[i].ProductPrice.ToString("c");
                    lblPrice.Size = new Size(200, 20);
                    lblPrice.Font = new Font("Microsoft Sans Serif", 10);
                    Controls.Add(lblPrice);

                    Label lblStar = new Label();
                    lblStar.Location = new Point(x + 400, y);
                    lblStar.Text = "★";
                    lblStar.Size = new Size(50, 50);
                    lblStar.Font = new Font(lblStar.Font.OriginalFontName, 30);
                    Controls.Add(lblStar);

                    Label lblRating = new Label();
                    lblRating.Location = new Point(x + 450, y + 20);
                    if (productList.Products[i].ProductRating == 0)
                    {
                        lblRating.Text = "Not yet rated.";
                    }
                    else
                    {
                        lblStar.ForeColor = Color.Yellow;
                        lblRating.Text = productList.Products[i].ProductRating.ToString("N1")
                            + " star avg rating";
                    }
                    Controls.Add(lblRating);

                    if (user.Type == 'r' || user.Type == 'b')
                    {
                        Button rateButton = new Button();
                        rateButton.Location = new Point(x + 5, y + 120);
                        rateButton.Text = "Rate";
                        rateButton.Tag = productList.Products[i].ProductName;
                        Controls.Add(rateButton);
                        if (productList.Products[i].IsAlreadyRated == true)
                           rateButton.Hide();
                        rateButton.Click += RateBtn_Click;
                    }
                    y += 200;                   
                }
            }
            else
            {
                lblNoProducts.Visible = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            UploaderControl uploaderControl = new UploaderControl(user.Username, this);
            uploaderControl.AddProduct();
        }

        private void RateBtn_Click(object sender, EventArgs e)
        {
            
            Button theButton = new Button();
            theButton = (Button)sender;
            RaterControl raterControl = new RaterControl(user, (string)theButton.Tag, this);
            raterControl.RateProduct();
        }
        
        private void lnkLblLogout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Close();
            LogoutControl logoutControl = new LogoutControl(user.Username);
            logoutControl.Logout(user.Username);                         
        }

        public void AddToList(Product product)
        {
            PictureBox picture = new PictureBox();
            picture.Location = new Point(x, y);
            picture.Size = new Size(125, 110);
            picture.SizeMode = PictureBoxSizeMode.StretchImage;
            picture.Image = product.ProductImage;
            Controls.Add(picture);

            Label lblProductName = new Label();
            lblProductName.Location = new Point(x + 130, y);
            lblProductName.Text = product.ProductName.Replace("''", "'");
            lblProductName.Size = new Size(200, 20);
            lblProductName.Font = new Font("Microsoft Sans Serif", 10);
            Controls.Add(lblProductName);

            Label lblUploader = new Label();
            lblUploader.Location = new Point(x + 130, y + 20);
            lblUploader.Text = "Uploaded by " +
                product.UploaderUsername;
            lblUploader.Size = new Size(200, 20);
            Controls.Add(lblUploader);

            Label lblPrice = new Label();
            lblPrice.Location = new Point(x + 130, y + 40);
            lblPrice.Text = product.ProductPrice.ToString("c");
            lblPrice.Size = new Size(200, 20);
            lblPrice.Font = new Font("Microsoft Sans Serif", 10);
            Controls.Add(lblPrice);

            Label lblStar = new Label();
            lblStar.Location = new Point(x + 400, y);
            lblStar.Text = "★";
            lblStar.Size = new Size(50, 50);
            lblStar.Font = new Font(lblStar.Font.OriginalFontName, 30);
            Controls.Add(lblStar);

            Label lblRating = new Label();
            lblRating.Location = new Point(x + 450, y + 20);
            lblRating.Text = "Not yet rated.";
            Controls.Add(lblRating);

            if (user.Type == 'r' || user.Type == 'b')
            {
                Button rateButton = new Button();
                rateButton.Location = new Point(x + 5, y + 120);
                rateButton.Text = "Rate";
                rateButton.Tag = product.ProductName;
                Controls.Add(rateButton);
                rateButton.Click += RateBtn_Click;
            }
            y += 200;
        }
    }
}
