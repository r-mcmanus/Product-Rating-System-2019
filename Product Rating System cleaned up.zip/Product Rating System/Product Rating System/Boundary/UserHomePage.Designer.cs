﻿namespace Product_Rating_System.Boundary
{
    partial class UserHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUsername = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblNoProducts = new System.Windows.Forms.Label();
            this.lblPipe = new System.Windows.Forms.Label();
            this.lnkLblLogout = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(936, 80);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(151, 29);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Current user:";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(584, 80);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(224, 92);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add Product";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblNoProducts
            // 
            this.lblNoProducts.AutoSize = true;
            this.lblNoProducts.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblNoProducts.Location = new System.Drawing.Point(492, 281);
            this.lblNoProducts.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNoProducts.Name = "lblNoProducts";
            this.lblNoProducts.Size = new System.Drawing.Size(376, 29);
            this.lblNoProducts.TabIndex = 2;
            this.lblNoProducts.Text = "No products have been uploaded.";
            this.lblNoProducts.Visible = false;
            // 
            // lblPipe
            // 
            this.lblPipe.AutoSize = true;
            this.lblPipe.Location = new System.Drawing.Point(1237, 80);
            this.lblPipe.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPipe.Name = "lblPipe";
            this.lblPipe.Size = new System.Drawing.Size(19, 29);
            this.lblPipe.TabIndex = 3;
            this.lblPipe.Text = "|";
            // 
            // lnkLblLogout
            // 
            this.lnkLblLogout.AutoSize = true;
            this.lnkLblLogout.Location = new System.Drawing.Point(1267, 80);
            this.lnkLblLogout.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lnkLblLogout.Name = "lnkLblLogout";
            this.lnkLblLogout.Size = new System.Drawing.Size(87, 29);
            this.lnkLblLogout.TabIndex = 4;
            this.lnkLblLogout.TabStop = true;
            this.lnkLblLogout.Text = "Logout";
            this.lnkLblLogout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLblLogout_LinkClicked);
            // 
            // UserHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1400, 816);
            this.Controls.Add(this.lnkLblLogout);
            this.Controls.Add(this.lblPipe);
            this.Controls.Add(this.lblNoProducts);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblUsername);
            this.Margin = new System.Windows.Forms.Padding(9, 9, 9, 9);
            this.Name = "UserHomePage";
            this.Text = "Home Page";
            this.Load += new System.EventHandler(this.UserHomePage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblNoProducts;
        private System.Windows.Forms.Label lblPipe;
        private System.Windows.Forms.LinkLabel lnkLblLogout;
    }
}
