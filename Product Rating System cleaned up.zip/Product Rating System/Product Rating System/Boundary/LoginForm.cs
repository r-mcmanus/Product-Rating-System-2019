﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Product_Rating_System.Control;
using Product_Rating_System.Entity;

namespace Product_Rating_System.Boundary
{
    public partial class LoginForm : Product_Rating_System.Boundary.Form1
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        private void btnOK_Click(object sender, EventArgs e)
        {

            LoginControl loginControl = new LoginControl();
            loginControl.Login(txtUsername.Text,
                txtPassword.Text);
            if (loginControl.User != null)
                Hide();
        }      
    }
}
