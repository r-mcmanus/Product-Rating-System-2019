﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Rating_System.Entity
{
    class UserLogoutRecord
    {
        public string LoggedOutUser { get; set; }
        public UserLogoutRecord(string user)
        {
            LoggedOutUser = user;
        }
    }
}
