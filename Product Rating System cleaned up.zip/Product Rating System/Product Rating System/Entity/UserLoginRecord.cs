﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Rating_System.Entity
{
    class UserLoginRecord
    {
        public string LoggedInUser { get; set; }        
        public UserLoginRecord (string user)
        {
            LoggedInUser = user;
        }
    }
}
